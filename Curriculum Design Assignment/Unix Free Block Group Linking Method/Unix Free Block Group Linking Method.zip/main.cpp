#include "header.h"
#include <Windows.h>
#include <iostream>
#include "AppStartUp.h"
#define PASSWORD 12345678  // NOLINT(clang-diagnostic-unused-macros)

int main() // NOLINT(bugprone-exception-escape)
{
	AppStartUp appStart;
	return 0;
}
